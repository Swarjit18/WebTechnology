<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
   
  <title> </title>
   
</head>
<body>
  
   
     <fieldset>
      
        <form method="POST" action="./profilePictureValidation.php">
          <fieldset >
            <legend> <b>Profile Picture</b></legend>
              <table>
                <tr>
                  <td>
                    <input type="file" id="img" name="img" accept="image/*" >
                    &nbsp;
                  <span id="errimg" style="color:red"></span>  
                  </td>
                  <td>
                    <input type="submit" value="Submit" name="submit">
                  </td>
                </tr>

              </table>

            
          </fieldset>
        </form>
     
        
      
       
    </fieldset>
    
    

     
  </form>

 

</body>
</html>